using python 3.8.10 and opencv 4.5.4
